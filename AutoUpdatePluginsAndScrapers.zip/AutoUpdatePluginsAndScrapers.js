;(()=>{var r=async()=>{for(;!window.stash;)await new Promise(e=>setTimeout(e,100));function t(e,a){let u=new Date(e);return new Date(a)>u}async function n(){try{return(await stash.callGQL({operationName:"InstalledPluginPackagesStatus",variables:{},query:`
                query InstalledPluginPackagesStatus {
                    installedPackages(type: Plugin) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>t(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function p(e){try{await stash.callGQL({operationName:"UpdatePluginPackages",variables:{packages:e},query:`
                mutation UpdatePluginPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Plugin, packages: $packages)
                  }`})}catch(a){console.error(a)}}async function i(){try{return(await stash.callGQL({operationName:"InstalledScraperPackagesStatus",variables:{},query:`
                query InstalledScraperPackagesStatus {
                    installedPackages(type: Scraper) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>t(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function g(e){try{await stash.callGQL({operationName:"UpdateScraperPackages",variables:{packages:e},query:`
                mutation UpdateScraperPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Scraper, packages: $packages)
                  }`})}catch(a){console.error(a)}}let c=await n();c.length&&await p(c);let s=await i();s.length&&await g(s)};r();})();(()=>{(()=>{async function t(a){let s={method:"POST",body:JSON.stringify(a),headers:{"Content-Type":"application/json"}};try{return(await window.fetch("/graphql",s)).json()}catch(n){console.error(n)}}async function i(){try{return(await t({operationName:"Plugins",variables:{},query:"query Plugins{plugins{id}}"})).data.plugins.map(s=>s.id)}catch(a){console.error(a)}}async function l(a){return(await i()).includes(a)}async function r(a,s){try{await t({operationName:"InstallPluginPackages",variables:{packages:[{id:a,sourceURL:s}]},query:"mutation InstallPluginPackages($packages: [PackageSpecInput!]!) {installPackages(type: Plugin, packages: $packages)}"})}catch(n){console.error(n)}}let c=[{id:"StashUserscriptLibrary",source:"https://stashapp.github.io/CommunityScripts/stable/index.yml"}],e=!1;c.forEach(async({id:a,source:s})=>{await l(a)||(await r(a,s),e=!0)}),setTimeout(()=>{e&&window.location.reload()},2e3)})();})()