;(async () => {
var n=async()=>{for(;!window.TetraxUSL?.stash;)await new Promise(e=>setTimeout(e,100));let t=window.TetraxUSL.stash;function c(e,a){let o=new Date(e);return new Date(a)>o}async function i(){try{return(await t.callGQL({operationName:"InstalledPluginPackagesStatus",variables:{},query:`
                query InstalledPluginPackagesStatus {
                    installedPackages(type: Plugin) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>c(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function p(e){try{await t.callGQL({operationName:"UpdatePluginPackages",variables:{packages:e},query:`
                mutation UpdatePluginPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Plugin, packages: $packages)
                  }`})}catch(a){console.error(a)}}async function u(){try{return(await t.callGQL({operationName:"InstalledScraperPackagesStatus",variables:{},query:`
                query InstalledScraperPackagesStatus {
                    installedPackages(type: Scraper) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>c(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function g(e){try{await t.callGQL({operationName:"UpdateScraperPackages",variables:{packages:e},query:`
                mutation UpdateScraperPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Scraper, packages: $packages)
                  }`})}catch(a){console.error(a)}}let r=await i();r.length&&await p(r);let s=await u();s.length&&await g(s)};(async()=>{for(;!(PluginApi&&PluginApi?.React);)await new Promise(t=>setTimeout(t,10));n()})();
})()
