;(async () => {
var r=async()=>{for(;!window.stash;)await new Promise(e=>setTimeout(e,100));function t(e,a){let g=new Date(e);return new Date(a)>g}async function n(){try{return(await stash.callGQL({operationName:"InstalledPluginPackagesStatus",variables:{},query:`
                query InstalledPluginPackagesStatus {
                    installedPackages(type: Plugin) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>t(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function i(e){try{await stash.callGQL({operationName:"UpdatePluginPackages",variables:{packages:e},query:`
                mutation UpdatePluginPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Plugin, packages: $packages)
                  }`})}catch(a){console.error(a)}}async function p(){try{return(await stash.callGQL({operationName:"InstalledScraperPackagesStatus",variables:{},query:`
                query InstalledScraperPackagesStatus {
                    installedPackages(type: Scraper) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>t(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function u(e){try{await stash.callGQL({operationName:"UpdateScraperPackages",variables:{packages:e},query:`
                mutation UpdateScraperPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Scraper, packages: $packages)
                  }`})}catch(a){console.error(a)}}let c=await n();c.length&&await i(c);let s=await p();s.length&&await u(s)};(async()=>{for(;!(PluginApi&&PluginApi?.React);)await new Promise(t=>setTimeout(t,10));r()})();
(async()=>{async function t(a){let s={method:"POST",body:JSON.stringify(a),headers:{"Content-Type":"application/json"}};try{return(await window.fetch("/graphql",s)).json()}catch(n){console.error(n)}}async function i(){try{return(await t({operationName:"Plugins",variables:{},query:"query Plugins{plugins{id}}"})).data.plugins.map(s=>s.id)}catch(a){console.error(a)}}async function l(a){return(await i()).includes(a)}async function r(a,s){try{await t({operationName:"InstallPluginPackages",variables:{packages:[{id:a,sourceURL:s}]},query:"mutation InstallPluginPackages($packages: [PackageSpecInput!]!) {installPackages(type: Plugin, packages: $packages)}"})}catch(n){console.error(n)}}let c=[{id:"StashUserscriptLibrary",source:"https://stashapp.github.io/CommunityScripts/stable/index.yml"}],e=!1;c.forEach(async({id:a,source:s})=>{await l(a)||(await r(a,s),e=!0)}),setTimeout(()=>{e&&window.location.reload()},2e3)})();
})()
