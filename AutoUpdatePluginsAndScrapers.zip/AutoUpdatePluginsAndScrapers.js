;(()=>{var s=async()=>{for(;!window.tetraxUSL?.utils;)await new Promise(e=>setTimeout(e,100));function t(e,a){let l=new Date(e);return new Date(a)>l}async function n(){try{return(await tetraxUSL.utils.callGQL({operationName:"InstalledPluginPackagesStatus",variables:{},query:`
                query InstalledPluginPackagesStatus {
                    installedPackages(type: Plugin) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>t(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function i(e){try{await tetraxUSL.utils.callGQL({operationName:"UpdatePluginPackages",variables:{packages:e},query:`
                mutation UpdatePluginPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Plugin, packages: $packages)
                  }`})}catch(a){console.error(a)}}async function u(){try{return(await tetraxUSL.utils.callGQL({operationName:"InstalledScraperPackagesStatus",variables:{},query:`
                query InstalledScraperPackagesStatus {
                    installedPackages(type: Scraper) {
                      ...PackageData
                      source_package {
                        ...PackageData
                        __typename
                      }
                      __typename
                    }
                  }
                  
                  fragment PackageData on Package {
                    package_id
                    name
                    version
                    date
                    metadata
                    sourceURL
                    __typename
                  }`})).data.installedPackages.filter(a=>t(a.date,a.source_package?.date)).map(a=>({id:a.package_id,sourceURL:a.sourceURL}))}catch(e){console.error(e)}}async function p(e){try{await tetraxUSL.utils.callGQL({operationName:"UpdateScraperPackages",variables:{packages:e},query:`
                mutation UpdateScraperPackages($packages: [PackageSpecInput!]!) {
                    updatePackages(type: Scraper, packages: $packages)
                  }`})}catch(a){console.error(a)}}let c=await n();c.length&&await i(c);let r=await u();r.length&&await p(r)};s();})()