;(async () => {
var i=async()=>{for(;!window.TetraxUSL?.stash;)await new Promise(t=>setTimeout(t,100));let e=window.TetraxUSL.stash;async function a(t){await e.waitForElement(".scene-card-preview-video",t,document.body,!0),document.querySelectorAll(".scene-card-preview-video").forEach(s=>{fetch(s.src).then(r=>{r.status!==200&&(s.src=s.src.replace("/preview","/stream"))})})}e.addEventListeners(["stash:page:scenes:grid","stash:page:any:scenes:grid"],()=>{a(5e3)})};(async()=>{for(;!(PluginApi&&PluginApi?.React);)await new Promise(e=>setTimeout(e,10));i()})();
})()
