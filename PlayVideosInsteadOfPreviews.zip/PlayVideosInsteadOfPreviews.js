;(async () => {
var a=async()=>{for(;!window.TetraxUSL?.stash;)await new Promise(i=>setTimeout(i,100));let e=window.TetraxUSL.stash;async function s(i){await e.waitForElement(".scene-card-preview-video",i,document.body,!0),document.querySelectorAll(".scene-card-preview-video").forEach(t=>{t.src=t.src.replace("/preview","/stream")})}e.addEventListeners(["stash:page:scenes:grid","stash:page:any:scenes:grid"],()=>{s(5e3)})};(async()=>{for(;!(PluginApi&&PluginApi?.React);)await new Promise(e=>setTimeout(e,10));a()})();
})()
