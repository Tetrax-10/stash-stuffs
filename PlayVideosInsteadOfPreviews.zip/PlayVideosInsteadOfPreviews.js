;(async () => {
var i=async()=>{for(;!window.TetraxUSL?.stash;)await new Promise(t=>setTimeout(t,100));let e=window.TetraxUSL.stash;async function s(t){await e.waitForElement(".scene-card-preview-video",t,document.body,!0),document.querySelectorAll(".scene-card-preview-video").forEach(a=>{a.src=a.src.replace("/preview","/stream")})}e.addEventListeners(["stash:page:scenes","stash:page:any:scenes:grid"],()=>{s(5e3)})};(async()=>{for(;!(PluginApi&&PluginApi?.React);)await new Promise(e=>setTimeout(e,10));i()})();
})()
